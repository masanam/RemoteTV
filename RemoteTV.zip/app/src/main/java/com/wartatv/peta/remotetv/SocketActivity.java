package com.wartatv.peta.remotetv;

/**
 * Created by User Pc on 22/2/2017.
 */
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class SocketActivity extends Activity {
    /** Called when the activity is first created. */

    private EditText ip_server ;
    private EditText port_server;
    private Button btn_tv;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ip_server = (EditText)findViewById(R.id.editText1);
        port_server = (EditText)findViewById(R.id.editText2);
        btn_tv = (Button)findViewById(R.id.button);
        btn_tv.setText(R.string.btn_tv);
        btn_tv.setOnClickListener(new btn_tvListener());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(0, 1, 1, R.string.exit);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == 1){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    class btn_tvListener implements OnClickListener{

        public void onClick(View v) {
            String ip_serverStr = ip_server.getText().toString();
            String port_serverStr = port_server.getText().toString();
            Intent intent = new Intent();
            intent.putExtra("ip",ip_serverStr);
            intent.putExtra("port",port_serverStr);
            intent.setClass(SocketActivity.this, MainActivity.class);
            SocketActivity.this.startActivity(intent);
        }
    }

}
